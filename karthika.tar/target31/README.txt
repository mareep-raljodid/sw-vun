This file contains materials for one instance of the buffer overflow lab.

Files:

    ctarget

Linux binary with code-injection vulnerability.

     cookie.txt

Text file containing 4-byte signature required for this lab instance.

     hex2raw

Utility program to generate byte sequences.  See documentation in lab
handout.

