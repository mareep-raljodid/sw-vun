This file contains materials for one instance of the buffer overflow lab.

Files:

    rtarget

Linux binary with code-injection vulnerability.

     farm.c

Source code for gadget farm present in this instance of rtarget.  You
can compile (use flag -Og) and disassemble it to look for gadgets.

     hex2raw

Utility program to generate byte sequences.  See documentation in lab
handout.

