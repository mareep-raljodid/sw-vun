/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_121()
{
    return 3281017047U;
}

unsigned addval_365(unsigned x)
{
    return x + 2421696868U;
}

unsigned addval_155(unsigned x)
{
    return x + 3284633928U;
}

void setval_451(unsigned *p)
{
    *p = 3351742792U;
}

unsigned addval_197(unsigned x)
{
    return x + 2425393496U;
}

unsigned getval_100()
{
    return 2428993864U;
}

unsigned addval_354(unsigned x)
{
    return x + 2428995912U;
}

void setval_400(unsigned *p)
{
    *p = 2425362667U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_444(unsigned *p)
{
    *p = 3227568777U;
}

unsigned getval_494()
{
    return 3281043849U;
}

void setval_397(unsigned *p)
{
    *p = 3281049225U;
}

unsigned getval_152()
{
    return 3524843145U;
}

unsigned addval_487(unsigned x)
{
    return x + 1942214273U;
}

void setval_332(unsigned *p)
{
    *p = 3523794573U;
}

unsigned addval_173(unsigned x)
{
    return x + 3767093467U;
}

unsigned getval_377()
{
    return 532925097U;
}

unsigned addval_382(unsigned x)
{
    return x + 3223374465U;
}

void setval_326(unsigned *p)
{
    *p = 3284831713U;
}

unsigned getval_416()
{
    return 3353381192U;
}

void setval_159(unsigned *p)
{
    *p = 3767126160U;
}

unsigned getval_129()
{
    return 3281046153U;
}

unsigned getval_103()
{
    return 2425408137U;
}

unsigned addval_483(unsigned x)
{
    return x + 2462157191U;
}

unsigned getval_280()
{
    return 3674784153U;
}

void setval_190(unsigned *p)
{
    *p = 2447411528U;
}

unsigned addval_248(unsigned x)
{
    return x + 2463533347U;
}

void setval_285(unsigned *p)
{
    *p = 2425405835U;
}

void setval_469(unsigned *p)
{
    *p = 2447411528U;
}

unsigned addval_357(unsigned x)
{
    return x + 2464188744U;
}

unsigned getval_353()
{
    return 3531915657U;
}

unsigned addval_441(unsigned x)
{
    return x + 3229931209U;
}

void setval_428(unsigned *p)
{
    *p = 3224945097U;
}

unsigned addval_307(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_460()
{
    return 3223896457U;
}

void setval_435(unsigned *p)
{
    *p = 3674789513U;
}

unsigned addval_106(unsigned x)
{
    return x + 3680551305U;
}

unsigned getval_442()
{
    return 3374369419U;
}

unsigned addval_202(unsigned x)
{
    return x + 2430634313U;
}

unsigned addval_493(unsigned x)
{
    return x + 2425473673U;
}

unsigned getval_252()
{
    return 3281311369U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
